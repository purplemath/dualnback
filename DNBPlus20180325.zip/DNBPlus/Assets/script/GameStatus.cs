﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameStatus{
    public static int currentBundleVersion = 3;
    public static SceneState currentSceneState = SceneState.title;
    public static int currentNLevel = 1;
    public const int maxNLevel = 99;
    public static bool canUpgradeN = false;

    public static RoundData currentRoundData;

    #region 弹幕相关

    #endregion

    public static void InitGameDatas()
    {
        GameSound.Init();
    }

    public static void StartGame()
    {
        canUpgradeN = false;
        currentRoundData = new RoundData(currentNLevel);
        currentRoundData.Output();
        currentSceneState = SceneState.playing;
        currentRoundData.PlayVoice();
    }
    
    public static void EndGame()
    {
        try
        {
            GameSlot.UpdateIQ(currentRoundData.RoundScore());
        }
        catch
        {
            Debug.Log("end round error in update iq");
        }
        /*try
        {
            GameSlot.historyData.AddRecord(GameSlot.IQ);
        }
        catch
        {
            Debug.Log("end round error in update history");
        }*/
        try
        {
            GameSlot.SaveGame();
        }
        catch
        {
            Debug.Log("end round error in save");
        }
        currentSceneState = SceneState.result;
    }

}

public enum SceneState
{
    title,mainMenu,help,authorInfo,reference,setting,playing,result,statistics
}
