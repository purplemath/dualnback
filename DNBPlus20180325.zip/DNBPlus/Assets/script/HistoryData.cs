﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Xml;

public class HistoryData
{
    /*public List<RecordData> historyRound = new List<RecordData>();
    public List<RecordData> historyDay = new List<RecordData>();
    public List<RecordData> historyMonth = new List<RecordData>();
    public string reportOfTimes = "";
    public string reportOfDays = "";
    public string reportOfMonths = "";*/
    public RecordList historyRound;
    public RecordList historyDay;
    public RecordList historyMonth;

    public HistoryData()
    {
        historyRound = new RecordList();
        historyDay = new RecordList();
        historyMonth = new RecordList();
    }

    public void AddRecord(int level, int rate, int time, int iq1)
    {
        UpdateHistory();//可能一轮训练后刚好过了12点
        historyRound.AddRecord(level, rate, time, iq1);
        if (historyRound.records.Count > 20)
        {
            historyRound.RemoveRecord(0);
        }
        Debug.Log(historyRound.XMLString);
        Debug.Log(historyDay.XMLString);
        Debug.Log(historyMonth.XMLString);
        GameSlot.SaveGame();
    }

    public void UpdateHistory()
    {
        if(historyRound.records.Count > 0)
        {
            if (System.DateTime.Now.Year > historyRound.LastYear ||
                System.DateTime.Now.Month > historyRound.LastMonth)
            {
                if(historyDay.LastDay == historyRound.LastDay && historyDay.LastMonth == historyRound.LastMonth && historyDay.LastYear == historyRound.LastYear)
                {

                }
                else
                {
                    SumRound();
                }
                if (historyMonth.LastMonth == historyDay.LastMonth && historyMonth.LastYear == historyDay.LastYear)
                {

                }
                else
                {
                    SumDay();
                }
            }
            else if (System.DateTime.Now.Day > historyRound.LastDay)
            {
                if (historyDay.LastDay == historyRound.LastDay && historyDay.LastMonth == historyRound.LastMonth && historyDay.LastYear == historyRound.LastYear)
                {

                }
                else
                {
                    SumRound();
                }
            }
        }
    }
    void SumRound()
    {
        int avg = 0;
        if (historyRound.records.Count > 0)
        {
            int i = historyRound.records.Count;
            int count = 0;
            avg += historyRound.records[i - 1].IQ;
            count += 1;
            i -= 1;
            while (i >= 1)
            {
                if(historyRound.records[i - 1].day == historyRound.LastDay && historyRound.records[i - 1].month == historyRound.LastMonth
                    && historyRound.records[i - 1].year == historyRound.LastYear)
                {
                    avg += historyRound.records[i - 1].IQ;
                    count += 1;
                    i -= 1;
                }
                else
                {
                    break;
                }
            }
            avg = Mathf.RoundToInt(avg * 1.0f / count);
            historyDay.AddRecord(1, 1, 1, avg, historyRound.LastYear, historyRound.LastMonth, historyRound.LastDay);
            if (historyDay.records.Count > 20)
            {
                historyDay.RemoveRecord(0);
            }
        }
    }
    void SumDay()
    {
        int avg = 0;
        if (historyDay.records.Count > 0)
        {
            int i = historyDay.records.Count;
            int count = 0;
            avg += historyDay.records[i - 1].IQ;
            count += 1;
            i -= 1;
            while (i >= 1)
            {
                if (historyDay.records[i - 1].month == historyDay.LastMonth
                    && historyDay.records[i - 1].year == historyDay.LastYear)
                {
                    avg += historyDay.records[i - 1].IQ;
                    count += 1;
                    i -= 1;
                }
                else
                {
                    break;
                }
            }
            avg = Mathf.RoundToInt(avg * 1.0f / count);
            historyMonth.AddRecord(1, 1, 1, avg, historyDay.LastYear, historyDay.LastMonth, historyDay.LastDay);
            if (historyMonth.records.Count > 20)
            {
                historyMonth.RemoveRecord(0);
            }
        }
    }

    public string HistoryDataXMLString
    {
        get
        {
            string str1 = "<history>";
            str1 += historyRound.XMLString;
            str1 += historyDay.XMLString;
            str1 += historyMonth.XMLString;
            str1 += "</history>";
            return str1;
        }
    }
    public void LoadFromXML(string xmlstr)
    {
        XmlDocument xd1 = new XmlDocument();
        xd1.LoadXml(xmlstr);
        historyRound.LoadFromXML(xd1.GetElementsByTagName("recordList")[0].OuterXml);
        historyDay.LoadFromXML(xd1.GetElementsByTagName("recordList")[1].OuterXml);
        historyMonth.LoadFromXML(xd1.GetElementsByTagName("recordList")[2].OuterXml);
        UpdateHistory();
    }

}
