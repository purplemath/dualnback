﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Xml;

public class GameSlot
{
    public static int currentSlotVersion = 3;
    public static RecordList dayData;
    public static HistoryData historyData;
    public static int IQ;

    public static void SaveGame()
    {
        PlayerPrefs.SetInt("_slotVersion", currentSlotVersion);
        PlayerPrefs.SetString("_slotData", GameSlotXMLString);
        PlayerPrefs.SetString("_historyData", historyData.HistoryDataXMLString);
    }

    public static void LoadGame()
    {
        IQ = 100;
        dayData = new RecordList();
        historyData = new HistoryData();
        if (PlayerPrefs.HasKey("_slotVersion"))
        {
            if(PlayerPrefs.GetInt("_slotVersion") == 3)
            {
                if (PlayerPrefs.HasKey("_slotData"))
                {
                    if (PlayerPrefs.GetString("_slotData") != "")
                    {
                        try
                        {
                            LoadFromXMLString(PlayerPrefs.GetString("_slotData"));
                            Debug.Log("slot loaded");
                            //Debug.Log(PlayerPrefs.GetString("_slotData"));

                        }
                        catch
                        {
                            Debug.Log("error in loading slot");
                            dayData = new RecordList();
                            SaveGame();
                        }
                    }
                    else
                    {
                        Debug.Log("error in loading slot");
                        dayData = new RecordList();
                        SaveGame();
                    }
                }
                else
                {
                    Debug.Log("not exist slot");
                    dayData = new RecordList();
                    SaveGame();
                }

                if (PlayerPrefs.HasKey("_historyData"))
                {
                    Debug.Log(PlayerPrefs.GetString("_historyData"));
                    try
                    {
                        historyData.LoadFromXML(PlayerPrefs.GetString("_historyData"));
                        Debug.Log("history loaded");
                        //Debug.Log(historyData.reportOfDays);
                        //Debug.Log(historyData.reportOfMonths);
                    }
                    catch
                    {
                        Debug.Log("not exist history");
                        historyData = new HistoryData();
                    }
                }
                else
                {
                    Debug.Log("not exist history");
                }
            }
            else
            {
                Debug.Log("old version slot");
            }
        }
        else
        {
            Debug.Log("old version slot");
        }
    }

    public static void LoadFromXMLString(string xmlstr)
    {
        XmlDocument xd1 = new XmlDocument();
        xd1.LoadXml(xmlstr);
        //Debug.Log(xd1.GetElementsByTagName("dd")[0].OuterXml);
        GameStatus.currentNLevel = int.Parse(xd1.GetElementsByTagName("n")[0].InnerText);
        IQ = int.Parse(xd1.GetElementsByTagName("iq")[0].InnerText);
        GameSound.volume = int.Parse(xd1.GetElementsByTagName("volume")[0].InnerText);
        GameSound.currentLibId = int.Parse(xd1.GetElementsByTagName("libId")[0].InnerText);
        dayData = new RecordList(xd1.GetElementsByTagName("recordList")[0].OuterXml);
        string dateNow = System.DateTime.Now.Date.ToString();
        if(dateNow != dayData.dateStr)
        {
            dayData = new RecordList();
        }
    }

    public static string GameSlotXMLString
    {
        get
        {
            string str1 = "<slot>";
            str1 += "<n>" + GameStatus.currentNLevel + "</n>";
            str1 += "<iq>" + IQ + "</iq>";
            str1 += "<volume>" + GameSound.volume + "</volume>";
            str1 += "<libId>" + GameSound.currentLibId + "</libId>";
            str1 += dayData.XMLString;
            str1 += "</slot>";
            return str1;
        }
    }

    public static void UpdateIQ(int currentRoundScore)
    {
        IQ = Mathf.RoundToInt((IQ + currentRoundScore) * 0.5f);
    }

}
