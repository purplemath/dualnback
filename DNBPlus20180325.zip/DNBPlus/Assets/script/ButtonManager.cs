﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonManager : MonoBehaviour {
    public void QuitGame()
    {
        Application.Quit();
    }

    public void GotoMainMenu()
    {
        GameSlot.SaveGame();
        GameStatus.currentSceneState = SceneState.mainMenu;
        Debug.Log(GameSlot.historyData.HistoryDataXMLString);
    }
    public void UpgradeNAndGotoMainMenu()
    {
        GameStatus.currentNLevel += 1;
        if (GameStatus.currentNLevel > GameStatus.maxNLevel) GameStatus.currentNLevel = GameStatus.maxNLevel;
        GameStatus.EndGame();
        GameStatus.currentSceneState = SceneState.mainMenu;
    }

    public void StartTrain()
    {
        GameStatus.StartGame();
    }

    public void GotoSetting()
    {
        GameStatus.currentSceneState = SceneState.setting;
    }

    public void GotoStatistics()
    {
        GameSlot.historyData.UpdateHistory();
        GameStatus.currentSceneState = SceneState.statistics;
    }

    public void GotoHelp()
    {
        GameStatus.currentSceneState = SceneState.help;
    }


    public void GotoAuthorInfo()
    {
        GameStatus.currentSceneState = SceneState.authorInfo;
    }

    public void GotoReference()
    {
        GameStatus.currentSceneState = SceneState.reference;
    }

    public void OpenQQGroup()
    {
        Application.OpenURL("https://jq.qq.com/?_wv=1027&k=5qUCSUC");
    }
    public void OpenWeChatSite()
    {
        Application.OpenURL("https://mp.weixin.qq.com/mp/profile_ext?action=home&__biz=MzAwOTU5MzcxNg==&scene=124#wechat_redirect");
    }
    public void NextSoundLib()
    {
        if(GameSound.currentLibId >= GameSound.soundLibName.Count)
        {
            GameSound.currentLibId = 1;
        }
        else
        {
            GameSound.currentLibId += 1;
        }
        GameSound.Play((GameSound.currentLibId - 1) * 10 + Random.Range(1, 10) + 1);
    }

    public void PreviousSoundLib()
    {
        if (GameSound.currentLibId <= 1)
        {
            GameSound.currentLibId = GameSound.soundLibName.Count;
        }
        else
        {
            GameSound.currentLibId -= 1;
        }
        GameSound.Play((GameSound.currentLibId - 1) * 10 + Random.Range(1, 10) + 1);
    }

    /*public void NextNLevel()
    {
        if(GameStatus.currentNLevel >= GameStatus.maxNLevel)
        {
            ;
        }
        else
        {
            GameStatus.currentNLevel += 1;
        }
    }

    public void PreviousNLevel()
    {
        if(GameStatus.currentNLevel <= 1)
        {
            ;
        }
        else
        {
            GameStatus.currentNLevel -= 1;
        }
    }*/

    public void PlusVolume()
    {
        if(GameSound.volume < 100)
        {
            GameSound.volume += 5;
            if(GameSound.volume > 100)
            {
                GameSound.volume = 100;
            }
            GameSound.soundChanged = true;
            GameSound.Play((GameSound.currentLibId - 1) * 10 + Random.Range(1, 10) + 1);
        }
    }

    public void MinusVolume()
    {
        if (GameSound.volume > 5)
        {
            GameSound.volume -= 5;
            if (GameSound.volume < 5)
            {
                GameSound.volume = 5;
            }
            GameSound.soundChanged = true;
            GameSound.Play((GameSound.currentLibId - 1) * 10 + Random.Range(1, 10) + 1);
        }
    }

    public void CheckVisual()
    {
        GameStatus.currentRoundData.AddVisualCheck();
    }

    public void CheckVoice()
    {
        GameStatus.currentRoundData.AddVoiceCheck();
    }
}
