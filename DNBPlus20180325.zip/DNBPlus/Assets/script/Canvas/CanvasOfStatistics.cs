﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CanvasOfStatistics : MonoBehaviour {
    Canvas ca;
    public GameObject list1;
    Text list1Text;
    public GameObject list2;
    Text list2Text;
    public GameObject list3;
    Text list3Text;


    // Use this for initialization
    void Start()
    {
        ca = GetComponent<Canvas>();
        list1Text = list1.GetComponent<Text>();
        list2Text = list2.GetComponent<Text>();
        list3Text = list3.GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        if(GameStatus.currentSceneState == SceneState.statistics)
        {
            ca.enabled = true;
            list1Text.text = GameSlot.historyData.historyRound.IQReport;
            list2Text.text = GameSlot.historyData.historyDay.IQReport;
            list3Text.text = GameSlot.historyData.historyMonth.IQReport;
        }
        else
        {
            ca.enabled = false;
        }
    }
}
