﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CanvasOfPlaying : MonoBehaviour {
    Canvas ca;
    public GameObject square;
    RectTransform squareRT;
    public GameObject correct1;
    RectTransform correct1RT;
    public GameObject correct2;
    RectTransform correct2RT;
    public GameObject wrong1;
    RectTransform wrong1RT;
    public GameObject wrong2;
    RectTransform wrong2RT;
    public GameObject nLevel;
    Text nLevelText;
    public GameObject nLevel1;
    Text nLevel1Text;
    public GameObject nLevel2;
    Text nLevel2Text;
    public GameObject progress;
    Text progressText;

    // Use this for initialization
    void Start()
    {
        ca = GetComponent<Canvas>();
        squareRT = square.GetComponent<RectTransform>();
        correct1RT = correct1.GetComponent<RectTransform>();
        correct2RT = correct2.GetComponent<RectTransform>();
        wrong1RT = wrong1.GetComponent<RectTransform>();
        wrong2RT = wrong2.GetComponent<RectTransform>();
        nLevelText = nLevel.GetComponent<Text>();
        nLevel1Text = nLevel1.GetComponent<Text>();
        nLevel2Text = nLevel2.GetComponent<Text>();
        progressText = progress.GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        if(GameStatus.currentSceneState == SceneState.playing)
        {
            ca.enabled = true;
            if (GameStatus.currentRoundData.moveOnCD >= 0f && GameStatus.currentRoundData.moveOnCD <= 1f)
            {
                switch (GameStatus.currentRoundData.visualIdList[GameStatus.currentRoundData.progressId - 1])
                {
                    case 1:
                        squareRT.localPosition = new Vector3(-160, 240, 0);
                        break;
                    case 2:
                        squareRT.localPosition = new Vector3(0, 240, 0);
                        break;
                    case 3:
                        squareRT.localPosition = new Vector3(160, 240, 0);
                        break;
                    case 4:
                        squareRT.localPosition = new Vector3(-160, 80, 0);
                        break;
                    case 5:
                        squareRT.localPosition = new Vector3(0, 80, 0);
                        break;
                    case 6:
                        squareRT.localPosition = new Vector3(160, 80, 0);
                        break;
                    case 7:
                        squareRT.localPosition = new Vector3(-160, -80, 0);
                        break;
                    case 8:
                        squareRT.localPosition = new Vector3(0, -80, 0);
                        break;
                    case 9:
                        squareRT.localPosition = new Vector3(160, -80, 0);
                        break;
                    default:
                        break;
                }
            }
            else
            {
                squareRT.localPosition = new Vector3(9999, 0, 0);
            }
            if(GameStatus.currentRoundData.progressVoiceMark == 1)
            {
                correct2RT.localPosition = new Vector3(220, -270, 0);
                wrong2RT.localPosition = new Vector3(9999, -270, 0);
            }
            else if(GameStatus.currentRoundData.progressVoiceMark == 2)
            {
                wrong2RT.localPosition = new Vector3(220, -270, 0);
                correct2RT.localPosition = new Vector3(9999, -270, 0);
            }
            else
            {
                correct2RT.localPosition = new Vector3(9999, -270, 0);
                wrong2RT.localPosition = new Vector3(9999, -270, 0);
            }
            if (GameStatus.currentRoundData.progressVisualMark == 1)
            {
                correct1RT.localPosition = new Vector3(-50, -270, 0);
                wrong1RT.localPosition = new Vector3(9999, -270, 0);
            }
            else if (GameStatus.currentRoundData.progressVisualMark == 2)
            {
                wrong1RT.localPosition = new Vector3(-50, -270, 0);
                correct1RT.localPosition = new Vector3(9999, -270, 0);
            }
            else
            {
                correct1RT.localPosition = new Vector3(9999, -270, 0);
                wrong1RT.localPosition = new Vector3(9999, -270, 0);
            }
            nLevelText.text = "当前N = " + GameStatus.currentNLevel;
            progressText.text = "当前进度 = " + GameStatus.currentRoundData.progressId + "/" + GameStatus.currentRoundData.totalCount;
            nLevel1Text.text = GameStatus.currentNLevel.ToString();
            nLevel2Text.text = GameStatus.currentNLevel.ToString();
        }
        else
        {
            ca.enabled = false;
        }
    }
}
