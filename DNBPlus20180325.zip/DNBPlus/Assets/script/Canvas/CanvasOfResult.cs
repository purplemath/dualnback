﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CanvasOfResult : MonoBehaviour {
    Canvas ca;
    public GameObject result;
    Text resultText;
    public GameObject btn1;
    RectTransform btn1RT;
    public GameObject btn2;
    RectTransform btn2RT;
    public GameObject btn;
    RectTransform btnRT;

    // Use this for initialization
    void Start()
    {
        ca = GetComponent<Canvas>();
        resultText = result.GetComponent<Text>();
        btn1RT = btn1.GetComponent<RectTransform>();
        btn2RT = btn2.GetComponent<RectTransform>();
        btnRT = btn.GetComponent<RectTransform>();
    }

    // Update is called once per frame
    void Update()
    {
        if(GameStatus.currentSceneState == SceneState.result)
        {
            ca.enabled = true;
            resultText.text = GameStatus.currentRoundData.resultStr;
            if (GameStatus.canUpgradeN)
            {
                btnRT.localPosition = new Vector3(9999, 0, 0);
                btn1RT.localPosition = new Vector3(0, -195, 0);
                btn2RT.localPosition = new Vector3(0, -363, 0);
            }
            else
            {
                btnRT.localPosition = new Vector3(0, -195, 0);
                btn1RT.localPosition = new Vector3(9999, 0, 0);
                btn2RT.localPosition = new Vector3(9999, 0, 0);
            }
        }
        else
        {
            ca.enabled = false;
        }
    }
}
