﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class CanvasOfSetting : MonoBehaviour {
    Canvas ca;
    public GameObject sound;
    Text soundText;
    public GameObject libId;
    Text libIdText;

    // Use this for initialization
    void Start()
    {
        ca = GetComponent<Canvas>();
        soundText = sound.GetComponent<Text>();
        libIdText = libId.GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        if(GameStatus.currentSceneState == SceneState.setting)
        {
            ca.enabled = true;
            soundText.text = GameSound.volume.ToString();
            libIdText.text = GameSound.soundLibName[GameSound.currentLibId - 1];
        }
        else
        {
            ca.enabled = false;
        }

    }
}
