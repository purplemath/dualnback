﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CanvasOfMainMenu : MonoBehaviour {
    Canvas ca;
    public GameObject nLevel;
    Text nLevelText;
    public GameObject todayTime;
    Text todayTimeText;
    public GameObject todayReport;
    Text todayReportText;
    public GameObject IQ;
    Text IQText;

    // Use this for initialization
    void Start () {
        ca = GetComponent<Canvas>();
        nLevelText = nLevel.GetComponent<Text>();
        todayTimeText = todayTime.GetComponent<Text>();
        todayReportText = todayReport.GetComponent<Text>();
        IQText = IQ.GetComponent<Text>();
    }
	
	// Update is called once per frame
	void Update () {
        if(GameStatus.currentSceneState == SceneState.mainMenu)
        {
            ca.enabled = true;
            nLevelText.text = "当前难度N（间隔） = " + GameStatus.currentNLevel;
            todayTimeText.text = "今日目标 = " + Mathf.RoundToInt(GameSlot.dayData.totalTime/60f) + " / 20 分钟";
            todayReportText.text = GameSlot.dayData.totalReport;
            IQText.text = "智商评估 = "+ GameSlot.IQ;
        }
        else
        {
            ca.enabled = false;
        }
	}
}
