﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Xml;

public class RecordList {
    public string dateStr = "";
    public List<RecordData> records = new List<RecordData>();
    public string totalReport = "";
    public string IQReport = "";
    public int totalTime = 0;

    public RecordList()
    {
        dateStr = System.DateTime.Now.Date.ToString();
    }

    public RecordList(string xmlstr)
    {
        LoadFromXML(xmlstr);
    }

    public string XMLString
    {
        get
        {
            string str1 = "<recordList>";
            str1 += "<date>" + dateStr + "</date>";
            str1 += "<count>" + records.Count + "</count>";
            for (int i = 1; i <= records.Count; i++)
            {
                str1 += records[i - 1].RecordDataXMLString;
            }
            str1 += "</recordList>";
            return str1;
        }
    }

    public void LoadFromXML(string xmlstr)
    {
        XmlDocument xd1 = new XmlDocument();
        xd1.LoadXml(xmlstr);
        dateStr = xd1.GetElementsByTagName("date")[0].InnerText;
        int count = 0;
        count = int.Parse(xd1.GetElementsByTagName("count")[0].InnerText);
        for (int i = 1; i <= count; i++)
        {
            records.Add(new RecordData(xd1.GetElementsByTagName("rd")[i - 1].OuterXml));
        }
        UpdateTotalReport();
    }

    public void UpdateTotalReport()
    {
        totalReport = "(今日最近10次成绩)\n……\n";
        totalTime = 0;
        for (int i = 1; i <= records.Count; i++)
        {
            totalTime += records[i - 1].totalTime;
        }
        for (int i = Mathf.Max(1, records.Count - 9); i <= records.Count; i++)
        {
            totalReport += records[i - 1].report;
            totalReport += "\n";
        }
        UpdateIQReport();
    }
    public void UpdateIQReport()
    {
        IQReport = "";
        for (int i = Mathf.Max(1, records.Count - 19); i <= records.Count; i++)
        {
            IQReport += records[i - 1].IQ + "\n";
        }
    }

    public string TotalReport
    {
        get
        {
            return totalReport;
        }
    }

    public void AddRecord(int level, int rate, int time, int iq1)
    {
        records.Add(new RecordData(level, rate, time, iq1));
        UpdateTotalReport();
    }
    public void AddRecord(int level, int rate, int time, int iq1,int year1,int month1,int day1)
    {
        records.Add(new RecordData(level, rate, time, iq1, year1,month1,day1));
        UpdateTotalReport();
    }
    public void RemoveRecord(int index)
    {
        records.RemoveAt(index);
        UpdateTotalReport();
    }

    public int LastDay
    {
        get
        {
            if (records.Count >= 1)
                return records[records.Count - 1].day;
            else
                return 0;
        }
    }
    public int LastMonth
    {
        get
        {
            if (records.Count >= 1)
                return records[records.Count - 1].month;
            else
                return 0;
        }
    }
    public int LastYear
    {
        get
        {
            if (records.Count >= 1)
                return records[records.Count - 1].year;
            else
                return 0;
        }
    }
}
