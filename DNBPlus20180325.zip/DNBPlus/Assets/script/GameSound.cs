﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameSound {
    public static List<string> soundLibName = new List<string>();
    public const int soundCount = 21;
    public static int currentLibId = 1;
    public static int volume = 30;
    public static bool soundChanged = false;

    public static bool[] isSoundStart = new bool[soundCount];

    public static void Play(int id)
    {
        isSoundStart[id - 1] = true;
    }

    public static void Init()
    {
        soundLibName.Add("数字by紫数");
        soundLibName.Add("字母by紫数");
    }

    public static void PlayRightSound()
    {
        isSoundStart[20] = true;
    }
}
