﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainGame : MonoBehaviour {

	// Use this for initialization
	void Start () {
        GameStatus.InitGameDatas();
        if(SystemInfo.operatingSystemFamily == OperatingSystemFamily.Windows)
        {
            Screen.SetResolution(540, 960, false);
        }
        else
        {
            Screen.SetResolution(540, 960, true);
        }
        //Debug.Log(System.DateTime.Now.ToString("yyyy/MM/dd HH:mm"));
        /*Debug.Log(System.DateTime.Now.ToString("yyyy"));
        Debug.Log(System.DateTime.Now.ToString("MM"));
        Debug.Log(System.DateTime.Now.ToString("dd"));*/
        /*Debug.Log(System.DateTime.Now.Year);
        Debug.Log(System.DateTime.Now.Month);
        Debug.Log(System.DateTime.Now.Day);*/
        GameSlot.LoadGame();
        //GameStatus.currentNLevel += 1;
        GameStatus.currentSceneState = SceneState.mainMenu;
	}
	
	// Update is called once per frame
	void Update () {
		if(GameStatus.currentSceneState == SceneState.playing)
        {
            GameStatus.currentRoundData.update();
        }
        if (Input.GetKeyUp(KeyCode.Escape))
        {
            if(GameStatus.currentSceneState == SceneState.mainMenu)
            {
                Application.Quit();
            }
            else
            {
                GameSlot.SaveGame();
                GameStatus.currentSceneState = SceneState.mainMenu;
                Debug.Log(GameSlot.historyData.HistoryDataXMLString);
            }
        }
	}
}
