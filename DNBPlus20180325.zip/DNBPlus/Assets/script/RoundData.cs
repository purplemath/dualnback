﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoundData{
    public int n;
    public int totalCount = 0;
    int randCount = 0;
    public List<int> voiceIdList = new List<int>();
    public List<int> visualIdList = new List<int>();
    public List<bool> voiceIsNBack = new List<bool>();
    public List<bool> visualIsNBack = new List<bool>();
    public List<bool> voiceHasChecked = new List<bool>();
    public List<bool> visualHasChecked = new List<bool>();
    public int finalVoicePair = 0;
    public int finalVisualPair = 0;

    public int voiceMistakes = 0;
    public int visualMistakes = 0;
    public float correctRate = 0f;
    public string resultStr = "";

    public int progressId = 0;
    public int progressVoiceMark = 0;   //0无标记，1正确，2错误
    public int progressVisualMark = 0;  //0无标记，1正确，2错误
    public float startTime = 0f;
    public float moveOnCD = 0f;
    public const float moveOnStep = 2.5f;

    public RoundData()
    {

    }

    public RoundData(int level)
    {
        n = level;
        randCount = (n + 3);
        totalCount = randCount * 5;
        for (int i=1;i<= totalCount; i++)
        {
            voiceIdList.Add(0);
            visualIdList.Add(0);
            voiceIsNBack.Add(false);
            visualIsNBack.Add(false);
            voiceHasChecked.Add(false);
            visualHasChecked.Add(false);
        }
        GenerateRandMatch();
    }


    public void update()
    {
        startTime += Time.deltaTime;
        moveOnCD += Time.deltaTime;
        if(moveOnCD >= moveOnStep)
        {
            moveOnCD -= moveOnStep;
            CheckAndMoveOn();
        }
        if (Input.GetKeyUp(KeyCode.S))//金手指，测试时用
        {
            correctRate = 0.4f;
            GameSlot.dayData.AddRecord(n, Mathf.RoundToInt(correctRate * 100), Mathf.RoundToInt(startTime), RoundScore());
            GameSlot.historyData.AddRecord(n, Mathf.RoundToInt(correctRate * 100), Mathf.RoundToInt(startTime), RoundScore());
            resultStr = "测试中断\n";
            GameStatus.EndGame();
        }
    }

    public void GenerateRandMatch()
    {
        int voiceGenerateCount = 0;
        int visualGenerateCount = 0;
        int x;
        int y;
        while(voiceGenerateCount < randCount)
        {
            x = Random.Range(1, totalCount + 1 - n);
            if(voiceIdList[x - 1] == 0 && voiceIdList[x + n - 1] == 0)
            {
                voiceGenerateCount += 1;
                y = Random.Range(1, 10);
                voiceIdList[x - 1] = y;
                voiceIdList[x + n - 1] = y;
            }
        }
        while (visualGenerateCount < randCount)
        {
            x = Random.Range(1, totalCount + 1 - n);
            if (visualIdList[x - 1] == 0 && visualIdList[x + n - 1] == 0)
            {
                visualGenerateCount += 1;
                y = Random.Range(1, 10);
                visualIdList[x - 1] = y;
                visualIdList[x + n - 1] = y;
            }
        }
        for (int i = 1; i <= totalCount; i++)
        {
            if (voiceIdList[i - 1] == 0)
            {
                voiceIdList[i - 1] = Random.Range(1, 10);
            }
            if (visualIdList[i - 1] == 0)
            {
                visualIdList[i - 1] = Random.Range(1, 10);
            }
        }
        for (int i = 1 + n; i <= totalCount; i++)
        {
            if (voiceIdList[i - 1] == voiceIdList[i - 1 - n])
            {
                finalVoicePair += 1;
                voiceIsNBack[i - 1] = true;
            }
            if (visualIdList[i - 1] == visualIdList[i - 1 - n])
            {
                finalVisualPair += 1;
                visualIsNBack[i - 1] = true;
            }
        }
        progressId = 1;
    }

    public void AddVoiceCheck()
    {
        voiceHasChecked[progressId - 1] = true;
        if (voiceIsNBack[progressId - 1] == voiceHasChecked[progressId - 1])
        {
            progressVoiceMark = 1;
        }
        else
        {
            progressVoiceMark = 2;
        }
    }

    public void AddVisualCheck()
    {
        visualHasChecked[progressId - 1] = true;
        if (visualIsNBack[progressId - 1] == visualHasChecked[progressId - 1])
        {
            progressVisualMark = 1;
        }
        else
        {
            progressVisualMark = 2;
        }
    }

    public void CheckAndMoveOn()
    {
        CheckAnswer();
        MoveOn();
    }

    public void CheckAnswer()
    {
        if(voiceIsNBack[progressId - 1] != voiceHasChecked[progressId - 1])
        {
            voiceMistakes += 1;
        }
        if (visualIsNBack[progressId - 1] != visualHasChecked[progressId - 1])
        {
            visualMistakes += 1;
        }
    }

    public void MoveOn()
    {
        //Debug.Log(GameStatus.currentSceneState);
        progressId += 1;
        progressVoiceMark = 0;
        progressVisualMark = 0;
        if (progressId > totalCount)
        {
            progressId -= 1;//避免不同步带来的数组溢出。
            CalcResultAndAddToRecords();
            if (correctRate > 0.8f)
            {
                if (GameStatus.currentNLevel < 9)
                {
                    resultStr += "高分！获得升级难度机会！\n是否现在把N升到" + (GameStatus.currentNLevel+1) + "？\n";
                    GameStatus.canUpgradeN = true;
                }
            }
            else if (correctRate < 0.4f)
            {
                if (GameStatus.currentNLevel > 1)
                {
                    GameStatus.currentNLevel -= 1;
                    resultStr += "N降到" + GameStatus.currentNLevel + "!";
                }
            }
            GameStatus.EndGame();
        }
        else
        {
            PlayVoice();
        }
    }

    public void CalcResultAndAddToRecords()
    {
        correctRate = 1 - (visualMistakes + voiceMistakes) * 1f / (finalVoicePair + finalVisualPair);
        correctRate = Mathf.Max(0, correctRate);
        GameSlot.dayData.AddRecord(n, Mathf.RoundToInt(correctRate * 100), Mathf.RoundToInt(startTime), RoundScore());
        GameSlot.historyData.AddRecord(n, Mathf.RoundToInt(correctRate * 100), Mathf.RoundToInt(startTime), RoundScore());
        resultStr = "视觉错误 = " + visualMistakes + " / " + finalVisualPair + "\n" + "听觉错误 = " + voiceMistakes + " / " + finalVoicePair + "\n" + "正确率 = "
            + Mathf.RoundToInt(correctRate * 100) + "%\n" + "智力评价 = " + RoundScore() + "\n";
    }

    public void PlayVoice()
    {
        if (progressId >= 1 && progressId <= totalCount)
        {
            GameSound.Play((GameSound.currentLibId - 1) * 10 + voiceIdList[progressId - 1] + 1);
        }
    }

    public void Output()
    {
        string str1 = "";
        for (int i = 1; i <= totalCount; i++)
        {
            str1 += voiceIdList[i - 1] + ",";
        }
        Debug.Log(str1);
        str1 = "";
        for (int i = 1; i <= totalCount; i++)
        {
            str1 += visualIdList[i - 1] + ",";
        }
        Debug.Log(str1);
    }

    public int RoundScore()
    {
        return 90 + (n - 1) * 12 + Mathf.RoundToInt(18 * correctRate);
    }
}
