﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager : MonoBehaviour {
    public GameObject[] soundList = new GameObject[GameSound.soundCount];

	// Use this for initialization
	void Start () {
        int i;
        for (i = 1; i <= GameSound.soundCount; i++)
        {
            soundList[i - 1].GetComponent<AudioSource>().Stop();
            soundList[i - 1].GetComponent<AudioSource>().volume = GameSound.volume * 0.01f;
        }
    }
	
	// Update is called once per frame
	void Update () {
        int i = 0;

        for (i = 1; i <= GameSound.soundCount; i++)
        {
            if (GameSound.isSoundStart[i - 1])
            {
                soundList[i - 1].GetComponent<AudioSource>().Play();
                GameSound.isSoundStart[i - 1] = false;
            }
        }

        if (GameSound.soundChanged)
        {
            GameSound.soundChanged = false;
            for (i = 1; i <= GameSound.soundCount; i++)
            {
                //soundList[i - 1].GetComponent<AudioSource>().Stop();//?
                soundList[i - 1].GetComponent<AudioSource>().volume = GameSound.volume * 0.01f;
            }
        }

    }
}
