﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Xml;

public class RecordData{
    public int n;
    public int correctRate;
    public int totalTime;
    public int IQ;
    public string report;
    public int year;
    public int month;
    public int day;

    public RecordData()
    {
        n = 1;
        correctRate = 100;
        totalTime = 30;
        IQ = 100;
        report = "";
        year = 0;
        month = 0;
        day = 0;
    }

    public RecordData(int level,int rate,int time,int iq1)
    {
        n = level;
        correctRate = rate;
        totalTime = time;
        IQ = iq1;
        report = "n = " + n +"; "+ totalTime + "秒; 正确率 = " + correctRate + "%; 评分 = " + IQ + ";";
        year = System.DateTime.Now.Year;
        month = System.DateTime.Now.Month;
        day = System.DateTime.Now.Day;
    }
    public RecordData(int level, int rate, int time, int iq1,int year1,int month1,int day1)
    {
        n = level;
        correctRate = rate;
        totalTime = time;
        IQ = iq1;
        report = "n = " + n + "; " + totalTime + "秒; 正确率 = " + correctRate + "%; 评分 = " + IQ + ";";
        year = year1;
        month = month1;
        day = day1;
    }

    public RecordData(string xmlstr)
    {
        XmlDocument xd1 = new XmlDocument();
        xd1.LoadXml(xmlstr);
        try
        {
            n = int.Parse(xd1.GetElementsByTagName("n")[0].InnerText);
            correctRate = int.Parse(xd1.GetElementsByTagName("r")[0].InnerText);
            totalTime = int.Parse(xd1.GetElementsByTagName("t")[0].InnerText);
            IQ = int.Parse(xd1.GetElementsByTagName("i")[0].InnerText);
            report = "n = " + n + "; " + totalTime + "秒; 正确率 = " + correctRate + "%; 评分 = " + IQ + ";";
            year = int.Parse(xd1.GetElementsByTagName("y")[0].InnerText);
            month = int.Parse(xd1.GetElementsByTagName("m")[0].InnerText);
            day = int.Parse(xd1.GetElementsByTagName("d")[0].InnerText);
        }
        catch
        {
            Debug.Log("wrong,"+totalTime);
        }
    }

    public string RecordDataXMLString
    {
        get
        {
            string str1 = "";
            str1 += "<rd>";
            str1 += "<n>" + n + "</n>";
            str1 += "<r>" + correctRate + "</r>";
            str1 += "<t>" + totalTime + "</t>";
            str1 += "<i>" + IQ + "</i>";
            str1 += "<y>" + year + "</y>";
            str1 += "<m>" + month + "</m>";
            str1 += "<d>" + day + "</d>";
            str1 += "</rd>";
            return str1;
        }
    }
}
